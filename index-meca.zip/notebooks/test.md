# test write from mobile

hello 1 2 3

inserting photos might not be as simple